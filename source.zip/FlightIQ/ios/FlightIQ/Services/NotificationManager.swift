import UserNotifications

final class NotificationManager {
    static let shared = NotificationManager()

    func requestPermission() async -> Bool {
        (try? await UNUserNotificationCenter.current()
            .requestAuthorization(options: [.alert, .sound, .badge])) ?? false
    }

    /// Local notification. Remote push (APNs) is NOT configured.
    func notify(_ a: AlertDTO) async {
        let c = UNMutableNotificationContent()
        c.title = a.kind == "target" ? "Target price reached" : "Price drop"
        c.body = a.message
        c.sound = .default
        let req = UNNotificationRequest(
            identifier: "alert-\(a.id)", content: c,
            trigger: UNTimeIntervalNotificationTrigger(timeInterval: 1, repeats: false))
        try? await UNUserNotificationCenter.current().add(req)
    }
}
