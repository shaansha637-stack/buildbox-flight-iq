import Foundation

enum APIError: LocalizedError {
    case notConfigured
    case server(Int, String)
    case network(String)

    var errorDescription: String? {
        switch self {
        case .notConfigured: return "Set the backend URL in Settings first."
        case .server(let code, let msg): return "Server error \(code): \(msg)"
        case .network(let msg): return "Network problem: \(msg)"
        }
    }
}

final class APIClient {
    static let shared = APIClient()

    private let session: URLSession = {
        let c = URLSessionConfiguration.default
        c.timeoutIntervalForRequest = 60
        return URLSession(configuration: c)
    }()

    var baseURL: String {
        (UserDefaults.standard.string(forKey: "backendURL") ?? "")
            .trimmingCharacters(in: CharacterSet(charactersIn: " /\n"))
    }

    /// Random ID that identifies this install to the backend (not real login).
    var deviceId: String {
        if let id = UserDefaults.standard.string(forKey: "deviceId") { return id }
        let id = UUID().uuidString
        UserDefaults.standard.set(id, forKey: "deviceId")
        return id
    }

    func send<T: Decodable>(_ path: String, method: String = "GET",
                            query: [URLQueryItem] = [], body: Data? = nil) async throws -> T {
        guard !baseURL.isEmpty, var comps = URLComponents(string: baseURL + path) else {
            throw APIError.notConfigured
        }
        if !query.isEmpty { comps.queryItems = query }
        guard let url = comps.url else { throw APIError.notConfigured }

        var req = URLRequest(url: url)
        req.httpMethod = method
        req.setValue(deviceId, forHTTPHeaderField: "X-Device-Id")
        let key = UserDefaults.standard.string(forKey: "appKey") ?? ""
        if !key.isEmpty { req.setValue(key, forHTTPHeaderField: "X-App-Key") }
        if let body = body {
            req.httpBody = body
            req.setValue("application/json", forHTTPHeaderField: "Content-Type")
        }
        do {
            let (data, resp) = try await session.data(for: req)
            let code = (resp as? HTTPURLResponse)?.statusCode ?? 0
            guard (200..<300).contains(code) else {
                let text = String(data: data, encoding: .utf8) ?? ""
                throw APIError.server(code, String(text.prefix(200)))
            }
            let decoder = JSONDecoder()
            decoder.keyDecodingStrategy = .convertFromSnakeCase
            return try decoder.decode(T.self, from: data)
        } catch let e as APIError {
            throw e
        } catch {
            throw APIError.network(error.localizedDescription)
        }
    }

    static func encode<T: Encodable>(_ value: T) throws -> Data {
        let e = JSONEncoder()
        e.keyEncodingStrategy = .convertToSnakeCase
        return try e.encode(value)
    }
}
