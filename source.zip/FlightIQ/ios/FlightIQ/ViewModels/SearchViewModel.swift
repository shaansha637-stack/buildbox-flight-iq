import Foundation

@MainActor
final class SearchViewModel: ObservableObject {
    @Published var origin = "RUH"
    @Published var destination = "COK"
    @Published var departureDate = Calendar.current.date(byAdding: .day, value: 14, to: Date()) ?? Date()
    @Published var returnDate = Calendar.current.date(byAdding: .day, value: 21, to: Date()) ?? Date()
    @Published var isOneWay = true
    @Published var passengers = 1
    @Published var cabin = "economy"
    @Published var currency = "SAR"
    @Published var directOnly = false
    @Published var offers: [FlightOffer] = []
    @Published var notes: [String] = []
    @Published var isLoading = false
    @Published var errorMessage: String?

    static let currencies = ["SAR", "USD", "EUR", "GBP", "INR", "AED"]
    static let cabins = [("economy", "Economy"), ("premium_economy", "Premium Economy"),
                         ("business", "Business"), ("first", "First")]

    var isValid: Bool {
        let o = origin.trimmingCharacters(in: .whitespaces).uppercased()
        let d = destination.trimmingCharacters(in: .whitespaces).uppercased()
        return o.count == 3 && d.count == 3 && o != d
    }

    var shown: [FlightOffer] {
        let list = directOnly ? offers.filter { $0.stops == 0 } : offers
        return list.sorted { $0.effectivePrice < $1.effectivePrice }
    }

    func search() async -> Bool {
        guard isValid else {
            errorMessage = "Enter two different 3-letter airport codes (e.g. RUH, COK)."
            return false
        }
        errorMessage = nil
        isLoading = true
        defer { isLoading = false }
        var q = [
            URLQueryItem(name: "origin", value: origin.trimmingCharacters(in: .whitespaces).uppercased()),
            URLQueryItem(name: "destination", value: destination.trimmingCharacters(in: .whitespaces).uppercased()),
            URLQueryItem(name: "depart_date", value: departureDate.apiString),
            URLQueryItem(name: "adults", value: String(passengers)),
            URLQueryItem(name: "cabin", value: cabin),
            URLQueryItem(name: "currency", value: currency),
        ]
        if !isOneWay { q.append(URLQueryItem(name: "return_date", value: returnDate.apiString)) }
        do {
            let r: SearchResponse = try await APIClient.shared.send("/v1/flights/search", query: q)
            offers = r.offers
            notes = r.providerStatus.filter { $0.value != "ok" }.map { "\($0.key): \($0.value)" }
            if r.offers.contains(where: { $0.source == "test" }) {
                notes.append("Test data: the backend uses a sandbox token, so these are not real fares.")
            }
            return true
        } catch {
            errorMessage = error.localizedDescription
            return false
        }
    }
}
