import Foundation

@MainActor
final class TrackerStore: ObservableObject {
    @Published var trackers: [Tracker] = []
    @Published var alerts: [AlertDTO] = []
    @Published var error: String?
    @Published var isLoading = false

    private let api = APIClient.shared

    func refresh() async {
        isLoading = true
        defer { isLoading = false }
        do {
            trackers = try await api.send("/v1/trackers")
            error = nil
        } catch {
            self.error = error.localizedDescription
        }
    }

    func create(_ t: TrackerIn) async -> String? {
        do {
            let _: Tracker = try await api.send("/v1/trackers", method: "POST",
                                                body: try APIClient.encode(t))
            await refresh()
            return nil
        } catch {
            return error.localizedDescription
        }
    }

    func delete(_ t: Tracker) async {
        do {
            let _: Ack = try await api.send("/v1/trackers/\(t.id)", method: "DELETE")
            trackers.removeAll { $0.id == t.id }
        } catch {
            self.error = error.localizedDescription
        }
    }

    func history(for t: Tracker) async throws -> History {
        try await api.send("/v1/trackers/\(t.id)/history")
    }

    /// Fetches alerts, shows local notifications for new ones, then marks them delivered.
    func refreshAlerts() async {
        guard !api.baseURL.isEmpty else { return }
        do {
            let list: [AlertDTO] = try await api.send("/v1/alerts")
            alerts = list
            let fresh = list.filter { !$0.delivered }
            guard !fresh.isEmpty else { return }
            for a in fresh { await NotificationManager.shared.notify(a) }
            let body = try JSONEncoder().encode(["ids": fresh.map { $0.id }])
            let _: Ack = try await api.send("/v1/alerts/ack", method: "POST", body: body)
        } catch {
            // Silent: alerts are best-effort.
        }
    }
}
