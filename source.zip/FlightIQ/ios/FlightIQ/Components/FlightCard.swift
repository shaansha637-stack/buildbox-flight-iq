import SwiftUI

struct FlightCard: View {
    let offer: FlightOffer
    let isCheapest: Bool

    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack {
                if isCheapest {
                    badge("CHEAPEST", .green)
                }
                Spacer()
                if offer.source == "test" {
                    badge("TEST DATA", .orange)
                } else {
                    badge("LIVE", .blue)
                }
            }
            HStack {
                VStack(alignment: .leading) {
                    Text(offer.departTime).font(.title3.bold())
                    Text(offer.origin).font(.caption).foregroundStyle(.secondary)
                }
                Spacer()
                VStack {
                    Text(offer.durationText).font(.caption)
                    Image(systemName: "airplane").foregroundStyle(.blue)
                    Text(offer.stopsText).font(.caption2).foregroundStyle(.secondary)
                }
                Spacer()
                VStack(alignment: .trailing) {
                    Text(offer.arriveTime).font(.title3.bold())
                    Text(offer.destination).font(.caption).foregroundStyle(.secondary)
                }
            }
            Divider()
            HStack(alignment: .top) {
                VStack(alignment: .leading) {
                    Text(offer.airline).font(.subheadline)
                    Text("\(offer.flightNumber) · \(offer.provider)")
                        .font(.caption).foregroundStyle(.secondary)
                }
                Spacer()
                VStack(alignment: .trailing) {
                    Text("\(offer.displayCurrency) \(Int(offer.effectivePrice.rounded()))")
                        .font(.title2.bold())
                    if offer.isConverted {
                        Text("Original: \(offer.currency) \(Int(offer.price.rounded()))")
                            .font(.caption2).foregroundStyle(.secondary)
                        if let asOf = offer.fxAsOf, !asOf.isEmpty {
                            Text("Converted, rates \(asOf.prefix(16))")
                                .font(.caption2).foregroundStyle(.secondary)
                        }
                    }
                }
            }
        }
        .padding()
        .background(Color(.secondarySystemBackground), in: RoundedRectangle(cornerRadius: 16))
        .overlay(RoundedRectangle(cornerRadius: 16)
            .stroke(isCheapest ? Color.green : Color.clear, lineWidth: 1.5))
    }

    private func badge(_ text: String, _ color: Color) -> some View {
        Text(text)
            .font(.caption2.bold())
            .padding(.horizontal, 8).padding(.vertical, 3)
            .background(color.opacity(0.2), in: Capsule())
            .foregroundStyle(color)
    }
}
