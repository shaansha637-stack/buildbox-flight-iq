import SwiftUI

@main
struct FlightIQApp: App {
    var body: some Scene {
        WindowGroup { RootView() }
    }
}

struct RootView: View {
    @StateObject private var store = TrackerStore()
    @Environment(\.scenePhase) private var phase

    var body: some View {
        TabView {
            SearchView()
                .tabItem { Label("Search", systemImage: "airplane") }
            TrackerListView()
                .tabItem { Label("Tracker", systemImage: "chart.line.uptrend.xyaxis") }
            AlertsView()
                .tabItem { Label("Alerts", systemImage: "bell") }
            SettingsView()
                .tabItem { Label("Settings", systemImage: "gearshape") }
        }
        .environmentObject(store)
        .tint(Color(red: 0.2, green: 0.5, blue: 1.0))
        .task { await store.refreshAlerts() }
        .onChange(of: phase) { _, newPhase in
            if newPhase == .active { Task { await store.refreshAlerts() } }
        }
    }
}
