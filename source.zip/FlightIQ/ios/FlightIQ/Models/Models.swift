import Foundation

struct FlightOffer: Codable, Identifiable {
    let id: String
    let provider: String
    let source: String          // "live" or "test"
    let airline: String
    let flightNumber: String
    let origin: String
    let destination: String
    let departAt: String
    let arriveAt: String
    let durationMinutes: Int
    let stops: Int
    let price: Double
    let currency: String
    let convertedPrice: Double?
    let convertedCurrency: String?
    let fxRate: Double?
    let fxAsOf: String?

    var effectivePrice: Double { convertedPrice ?? price }
    var displayCurrency: String { convertedPrice != nil ? (convertedCurrency ?? currency) : currency }
    var isConverted: Bool { convertedPrice != nil }
    var departTime: String { String(departAt.dropFirst(11).prefix(5)) }
    var arriveTime: String { String(arriveAt.dropFirst(11).prefix(5)) }
    var durationText: String { "\(durationMinutes / 60)h \(durationMinutes % 60)m" }
    var stopsText: String { stops == 0 ? "Direct" : "\(stops) stop" + (stops > 1 ? "s" : "") }
}

struct SearchResponse: Codable {
    let offers: [FlightOffer]
    let providerStatus: [String: String]
}

struct Tracker: Codable, Identifiable, Hashable {
    let id: Int
    let origin: String
    let destination: String
    let departDate: String
    let returnDate: String?
    let adults: Int
    let cabin: String
    let currency: String
    let targetPrice: Double?
    let active: Bool
    let latestPrice: Double?
    let lowestPrice: Double?
}

struct TrackerIn: Encodable {
    let origin: String
    let destination: String
    let departDate: String
    let returnDate: String?
    let adults: Int
    let cabin: String
    let currency: String
    let targetPrice: Double?
}

struct PricePointDTO: Codable, Identifiable {
    let checkedAt: String
    let price: Double
    var id: String { checkedAt }
    var date: Date { DateParse.utc(checkedAt) ?? Date() }
}

struct History: Codable {
    let currency: String
    let points: [PricePointDTO]
    let lowest: Double?
    let highest: Double?
    let latest: Double?
    let average: Double?
    let changePct: Double?
    let lastChecked: String?
}

struct AlertDTO: Codable, Identifiable {
    let id: Int
    let trackerId: Int
    let kind: String
    let oldPrice: Double?
    let newPrice: Double
    let currency: String
    let pct: Double?
    let message: String
    let createdAt: String
    let delivered: Bool
}

struct Ack: Decodable { let ok: Bool }

enum DateParse {
    /// Backend sends UTC timestamps without a timezone suffix.
    static func utc(_ s: String) -> Date? {
        ISO8601DateFormatter().date(from: String(s.prefix(19)) + "Z")
    }
}

extension Date {
    var apiString: String {
        let f = DateFormatter()
        f.locale = Locale(identifier: "en_US_POSIX")
        f.dateFormat = "yyyy-MM-dd"
        return f.string(from: self)
    }
}
