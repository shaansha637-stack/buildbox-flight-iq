import SwiftUI

struct SettingsView: View {
    @AppStorage("backendURL") private var backendURL = ""
    @AppStorage("appKey") private var appKey = ""
    @State private var status = ""

    var body: some View {
        NavigationStack {
            Form {
                Section("Backend") {
                    TextField("https://your-app.onrender.com", text: $backendURL)
                        .textInputAutocapitalization(.never)
                        .autocorrectionDisabled()
                        .keyboardType(.URL)
                    SecureField("App key (if you set APP_API_KEY)", text: $appKey)
                    Button("Test connection") {
                        Task { status = await test() }
                    }
                    if !status.isEmpty { Text(status).font(.footnote) }
                }
                Section("Notifications") {
                    Button("Allow notifications") {
                        Task {
                            let ok = await NotificationManager.shared.requestPermission()
                            status = ok ? "Notifications allowed." : "Notifications not allowed."
                        }
                    }
                    Text("Price alerts are fetched when you open the app. Remote push (APNs) is not set up.")
                        .font(.footnote).foregroundStyle(.secondary)
                }
                Section("About") {
                    LabeledContent("Version", value: "1.0")
                    Link("Rates By Exchange Rate API", destination: URL(string: "https://www.exchangerate-api.com")!)
                    Text("The app key is stored on this device and is not a strong secret.")
                        .font(.footnote).foregroundStyle(.secondary)
                }
            }
            .navigationTitle("Settings")
        }
    }

    private func test() async -> String {
        let base = backendURL.trimmingCharacters(in: CharacterSet(charactersIn: " /\n"))
        guard let url = URL(string: base + "/health") else { return "Invalid URL." }
        do {
            let (data, resp) = try await URLSession.shared.data(from: url)
            let code = (resp as? HTTPURLResponse)?.statusCode ?? 0
            let body = String(data: data, encoding: .utf8) ?? ""
            return code == 200 ? "Connected: \(body)" : "Server answered \(code)."
        } catch {
            return "Failed: \(error.localizedDescription)"
        }
    }
}
