import SwiftUI

struct ResultsView: View {
    @ObservedObject var vm: SearchViewModel
    @State private var showTrack = false

    var body: some View {
        ScrollView {
            LazyVStack(spacing: 12) {
                Toggle("Direct flights only", isOn: $vm.directOnly)
                ForEach(vm.notes, id: \.self) { note in
                    Label(note, systemImage: "info.circle")
                        .font(.footnote)
                        .padding(10)
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .background(Color.orange.opacity(0.15), in: RoundedRectangle(cornerRadius: 10))
                }
                let list = vm.shown
                if list.isEmpty {
                    Text("No flights found.").foregroundStyle(.secondary).padding(.top, 40)
                }
                ForEach(Array(list.enumerated()), id: \.element.id) { index, offer in
                    FlightCard(offer: offer, isCheapest: index == 0)
                }
            }
            .padding()
        }
        .navigationTitle("\(vm.origin.uppercased()) → \(vm.destination.uppercased())")
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            Button("Track", systemImage: "bell.badge") { showTrack = true }
        }
        .sheet(isPresented: $showTrack) { TrackSheet(vm: vm) }
    }
}

struct TrackSheet: View {
    @ObservedObject var vm: SearchViewModel
    @EnvironmentObject var store: TrackerStore
    @Environment(\.dismiss) private var dismiss
    @State private var target = ""
    @State private var saving = false
    @State private var message: String?

    var body: some View {
        NavigationStack {
            Form {
                Section("Route") {
                    Text("\(vm.origin.uppercased()) → \(vm.destination.uppercased())")
                    Text(vm.departureDate.apiString)
                }
                Section("Target price in \(vm.currency) (optional)") {
                    TextField("e.g. 1200", text: $target).keyboardType(.decimalPad)
                }
                if let message = message {
                    Text(message).foregroundStyle(.red).font(.footnote)
                }
                Button("Start tracking") {
                    Task {
                        saving = true
                        let t = TrackerIn(
                            origin: vm.origin.uppercased(), destination: vm.destination.uppercased(),
                            departDate: vm.departureDate.apiString,
                            returnDate: vm.isOneWay ? nil : vm.returnDate.apiString,
                            adults: vm.passengers, cabin: vm.cabin, currency: vm.currency,
                            targetPrice: Double(target.replacingOccurrences(of: ",", with: ".")))
                        message = await store.create(t)
                        saving = false
                        if message == nil { dismiss() }
                    }
                }
                .disabled(saving)
            }
            .navigationTitle("Track this route")
            .toolbar { Button("Close") { dismiss() } }
        }
    }
}
