import SwiftUI

struct TrackerListView: View {
    @EnvironmentObject var store: TrackerStore

    var body: some View {
        NavigationStack {
            List {
                if let e = store.error {
                    Text(e).foregroundStyle(.red).font(.footnote)
                }
                if store.trackers.isEmpty && store.error == nil {
                    Text("No tracked routes yet. Search for a flight and tap Track.")
                        .foregroundStyle(.secondary)
                }
                ForEach(store.trackers) { t in
                    NavigationLink(value: t) {
                        VStack(alignment: .leading, spacing: 4) {
                            Text("\(t.origin) → \(t.destination)").font(.headline)
                            Text(t.returnDate == nil ? t.departDate : "\(t.departDate) – \(t.returnDate ?? "")")
                                .font(.caption).foregroundStyle(.secondary)
                            if let latest = t.latestPrice {
                                Text("Now \(t.currency) \(Int(latest.rounded()))")
                            } else {
                                Text("Waiting for first price check…").foregroundStyle(.secondary)
                            }
                            if let target = t.targetPrice {
                                Text("Target \(t.currency) \(Int(target.rounded()))")
                                    .font(.caption).foregroundStyle(.blue)
                            }
                            if !t.active {
                                Text("Inactive (date passed)").font(.caption).foregroundStyle(.orange)
                            }
                        }
                    }
                }
                .onDelete { idx in
                    let items = idx.map { store.trackers[$0] }
                    Task { for t in items { await store.delete(t) } }
                }
            }
            .navigationTitle("Price Tracker")
            .navigationDestination(for: Tracker.self) { HistoryView(tracker: $0) }
            .refreshable { await store.refresh() }
            .task { await store.refresh() }
        }
    }
}
