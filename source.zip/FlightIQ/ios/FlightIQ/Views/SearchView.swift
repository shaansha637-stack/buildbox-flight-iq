import SwiftUI

struct SearchView: View {
    @StateObject private var vm = SearchViewModel()
    @State private var showResults = false

    var body: some View {
        NavigationStack {
            Form {
                Section("Route") {
                    TextField("From (e.g. RUH)", text: $vm.origin)
                        .textInputAutocapitalization(.characters)
                        .autocorrectionDisabled()
                    TextField("To (e.g. COK)", text: $vm.destination)
                        .textInputAutocapitalization(.characters)
                        .autocorrectionDisabled()
                }
                Section("Trip") {
                    Toggle("One way", isOn: $vm.isOneWay)
                    DatePicker("Departure", selection: $vm.departureDate,
                               in: Date()..., displayedComponents: .date)
                    if !vm.isOneWay {
                        DatePicker("Return", selection: $vm.returnDate,
                                   in: vm.departureDate..., displayedComponents: .date)
                    }
                    Stepper("Passengers: \(vm.passengers)", value: $vm.passengers, in: 1...9)
                    Picker("Cabin", selection: $vm.cabin) {
                        ForEach(SearchViewModel.cabins, id: \.0) { Text($0.1).tag($0.0) }
                    }
                    Picker("Show prices in", selection: $vm.currency) {
                        ForEach(SearchViewModel.currencies, id: \.self) { Text($0) }
                    }
                }
                if let msg = vm.errorMessage {
                    Text(msg).foregroundStyle(.red).font(.footnote)
                }
                Button {
                    Task { showResults = await vm.search() }
                } label: {
                    HStack {
                        Spacer()
                        if vm.isLoading { ProgressView() } else { Text("Search flights").bold() }
                        Spacer()
                    }
                }
                .disabled(vm.isLoading)
            }
            .navigationTitle("FlightIQ")
            .navigationDestination(isPresented: $showResults) { ResultsView(vm: vm) }
        }
    }
}
