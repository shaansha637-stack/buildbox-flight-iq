import SwiftUI
import Charts

struct HistoryView: View {
    let tracker: Tracker
    @EnvironmentObject var store: TrackerStore
    @State private var history: History?
    @State private var error: String?

    var body: some View {
        List {
            if let e = error {
                Text(e).foregroundStyle(.red).font(.footnote)
            }
            if let h = history {
                if h.points.count > 1 {
                    Chart(h.points) { p in
                        LineMark(x: .value("Checked", p.date), y: .value("Price", p.price))
                            .interpolationMethod(.monotone)
                        PointMark(x: .value("Checked", p.date), y: .value("Price", p.price))
                    }
                    .chartYScale(domain: .automatic(includesZero: false))
                    .frame(height: 220)
                    .padding(.vertical, 8)
                } else {
                    Text("Not enough data for a chart yet. Prices are re-checked every few hours.")
                        .foregroundStyle(.secondary)
                }
                Section("Statistics (\(h.currency))") {
                    stat("Latest", h.latest)
                    stat("Lowest", h.lowest)
                    stat("Highest", h.highest)
                    stat("Average", h.average)
                    if let c = h.changePct {
                        LabeledContent("Last change", value: String(format: "%+.1f%%", c))
                    }
                    if let d = h.lastChecked.flatMap({ DateParse.utc($0) }) {
                        LabeledContent("Last checked", value: d.formatted(date: .abbreviated, time: .shortened))
                    }
                }
            } else if error == nil {
                ProgressView()
            }
        }
        .navigationTitle("\(tracker.origin) → \(tracker.destination)")
        .navigationBarTitleDisplayMode(.inline)
        .task {
            do { history = try await store.history(for: tracker) }
            catch { self.error = error.localizedDescription }
        }
    }

    @ViewBuilder
    private func stat(_ label: String, _ v: Double?) -> some View {
        if let v = v {
            LabeledContent(label, value: String(Int(v.rounded())))
        }
    }
}
