import SwiftUI

struct AlertsView: View {
    @EnvironmentObject var store: TrackerStore

    var body: some View {
        NavigationStack {
            List {
                if store.alerts.isEmpty {
                    Text("No alerts yet. They appear here when a tracked price drops or hits your target.")
                        .foregroundStyle(.secondary)
                }
                ForEach(store.alerts) { a in
                    VStack(alignment: .leading, spacing: 4) {
                        Label(a.kind == "target" ? "Target reached" : "Price drop",
                              systemImage: a.kind == "target" ? "target" : "arrow.down.circle")
                            .font(.headline)
                            .foregroundStyle(a.kind == "target" ? .green : .blue)
                        Text(a.message)
                        if let d = DateParse.utc(a.createdAt) {
                            Text(d.formatted(date: .abbreviated, time: .shortened))
                                .font(.caption).foregroundStyle(.secondary)
                        }
                    }
                }
            }
            .navigationTitle("Alerts")
            .refreshable { await store.refreshAlerts() }
        }
    }
}
