# FlightIQ (Phase 1)

SwiftUI iOS app + GitHub Actions unsigned build. Uses SAMPLE data only.

## Build
1. Upload all files to a GitHub repo (keep the folder structure).
2. Actions tab -> "Build unsigned iOS app" -> Run workflow.
3. Download the artifact `FlightIQ-unsigned-ipa` (contains FlightIQ-unsigned.ipa).

## Installing
The IPA is UNSIGNED. iPhone will not install it as is.
It must be signed first (Apple Developer account, or a sideloading tool that re-signs it).

## Layout
- project.yml: XcodeGen config (the .xcodeproj is generated in CI)
- ios/FlightIQ: Swift sources
- .github/workflows/ios-unsigned.yml: build workflow

## Backend (FastAPI + Duffel + SQLite/PostgreSQL)
Endpoints (send X-Device-Id on all /v1 calls; X-App-Key if APP_API_KEY is set):
- GET /health
- GET /v1/flights/search?origin&destination&depart_date&return_date&adults&cabin&currency
- POST/GET /v1/trackers, DELETE /v1/trackers/{id}, GET /v1/trackers/{id}/history
- GET /v1/alerts, POST /v1/alerts/ack
- GET /v1/currency/rates?base=SAR

Deploy: render.yaml (Render.com). Set DUFFEL_TOKEN, APP_API_KEY, DATABASE_URL in the host's
environment settings, never in git. SQLite data is LOST on free hosts when they restart;
use PostgreSQL (DATABASE_URL) for real use.

Prices keep the provider's original currency and are converted via ExchangeRate-API
(open access, attribution required). The original price is always shown too.

## iOS app
Open Settings tab, enter the backend URL (and app key), tap Test connection.
Alerts are local notifications created when the app is opened. Remote push (APNs) is NOT set up.

## Not included yet
Airport autocomplete, flexible-date search, other providers (Skyscanner/Trip.com),
remote push, user login, unit tests.
