import asyncio
import logging
from datetime import date

from sqlalchemy import select
from sqlalchemy.orm import Session

from ..config import settings
from ..db import SessionLocal
from ..models import Alert, PricePoint, Tracker
from ..providers.base import ProviderError
from ..providers.duffel import DuffelProvider
from .currency import CurrencyError, convert

log = logging.getLogger("flightiq.checker")


async def check_tracker(db: Session, t: Tracker) -> None:
    if t.depart_date < date.today():
        t.active = False
        db.commit()
        return
    provider = DuffelProvider(settings.duffel_token)
    offers = await provider.search(t.origin, t.destination, t.depart_date,
                                   t.return_date, t.adults, t.cabin)
    priced = []
    for o in offers:
        try:
            val = (await convert(o.price, o.currency, t.currency))[0]
        except CurrencyError:
            if o.currency != t.currency:
                continue
            val = o.price
        priced.append((val, o))
    if not priced:
        log.info("Tracker %s: no usable offers", t.id)
        return
    new, best = min(priced, key=lambda x: x[0])

    prev = db.scalars(select(PricePoint).where(PricePoint.tracker_id == t.id)
                      .order_by(PricePoint.id.desc())).first()
    db.add(PricePoint(tracker_id=t.id, price=new, original_price=best.price,
                      original_currency=best.currency, provider=best.provider,
                      source=best.source, airline=best.airline))

    old = prev.price if prev else None
    route = f"{t.origin}→{t.destination}"
    alert = None
    if t.target_price and new <= t.target_price and (old is None or old > t.target_price):
        alert = Alert(kind="target", old_price=old, new_price=new,
                      message=f"{route}: target reached! Now {t.currency} {new:.0f}")
    elif old and new < old and (old - new) / old * 100 >= 1:
        pct = (old - new) / old * 100
        alert = Alert(kind="drop", old_price=old, new_price=new, pct=pct,
                      message=f"{route}: {t.currency} {old:.0f} → {new:.0f} (-{pct:.0f}%)")
    if alert:
        alert.tracker_id, alert.device_id, alert.currency = t.id, t.device_id, t.currency
        if alert.old_price and not alert.pct:
            alert.pct = (alert.old_price - new) / alert.old_price * 100
        db.add(alert)
    db.commit()


async def check_one(tracker_id: int) -> None:
    db = SessionLocal()
    try:
        t = db.get(Tracker, tracker_id)
        if t and t.active and settings.duffel_token:
            await check_tracker(db, t)
    except ProviderError as e:
        log.warning("Tracker %s check failed: %s", tracker_id, e)
    except Exception:
        log.exception("Tracker %s check crashed", tracker_id)
    finally:
        db.close()


async def check_all() -> None:
    db = SessionLocal()
    try:
        ids = list(db.scalars(select(Tracker.id).where(Tracker.active.is_(True))))
    finally:
        db.close()
    for tid in ids:
        await check_one(tid)
        await asyncio.sleep(3)  # stay far below provider rate limits
