"""Exchange rates from ExchangeRate-API open access (attribution required:
https://www.exchangerate-api.com). Rates update daily; we cache for 6 hours."""
import time

import httpx


class CurrencyError(Exception):
    pass


_cache: dict[str, tuple[float, dict, str]] = {}
TTL = 6 * 3600


async def get_rates(base: str) -> tuple[dict, str]:
    base = base.upper()
    hit = _cache.get(base)
    if hit and time.time() - hit[0] < TTL:
        return hit[1], hit[2]
    try:
        async with httpx.AsyncClient(timeout=10) as c:
            r = await c.get(f"https://open.er-api.com/v6/latest/{base}")
            r.raise_for_status()
            data = r.json()
        if data.get("result") != "success":
            raise CurrencyError("Rate service returned an error")
    except (httpx.HTTPError, ValueError) as e:
        if hit:  # serve stale rates, with their true (older) timestamp
            return hit[1], hit[2]
        raise CurrencyError("Exchange rates unavailable") from e
    rates, as_of = data["rates"], data.get("time_last_update_utc", "")
    _cache[base] = (time.time(), rates, as_of)
    return rates, as_of


async def convert(amount: float, frm: str, to: str) -> tuple[float, float, str]:
    """Returns (converted_amount, rate, rates_as_of)."""
    frm, to = frm.upper(), to.upper()
    if frm == to:
        return amount, 1.0, ""
    rates, as_of = await get_rates(frm)
    rate = rates.get(to)
    if rate is None:
        raise CurrencyError(f"No rate for {frm}->{to}")
    return round(amount * rate, 2), rate, as_of
