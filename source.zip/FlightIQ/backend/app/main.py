import logging
from contextlib import asynccontextmanager
from datetime import date
from typing import Annotated

from fastapi import Depends, FastAPI, Header, HTTPException, Query

from . import scheduler
from .config import settings
from .db import Base, engine
from .providers.base import ProviderError
from .providers.duffel import DuffelProvider
from .routes import router
from .schemas import Cabin, SearchResponse
from .services.currency import CurrencyError, convert

logging.basicConfig(level=logging.INFO)


@asynccontextmanager
async def lifespan(app: FastAPI):
    Base.metadata.create_all(engine)
    scheduler.start()
    yield
    scheduler.stop()


app = FastAPI(title="FlightIQ API", version="0.3.0", lifespan=lifespan)


def check_key(x_app_key: Annotated[str | None, Header()] = None) -> None:
    if settings.app_api_key and x_app_key != settings.app_api_key:
        raise HTTPException(status_code=401, detail="Invalid app key")


app.include_router(router, dependencies=[Depends(check_key)])


@app.get("/health")
async def health():
    return {"status": "ok", "duffel_configured": bool(settings.duffel_token)}


@app.get("/v1/flights/search", response_model=SearchResponse,
         dependencies=[Depends(check_key)])
async def search_flights(
    origin: Annotated[str, Query(pattern=r"^[A-Za-z]{3}$")],
    destination: Annotated[str, Query(pattern=r"^[A-Za-z]{3}$")],
    depart_date: date,
    return_date: date | None = None,
    adults: Annotated[int, Query(ge=1, le=9)] = 1,
    cabin: Cabin = "economy",
    currency: Annotated[str | None, Query(pattern=r"^[A-Za-z]{3}$")] = None,
):
    origin, destination = origin.upper(), destination.upper()
    if origin == destination:
        raise HTTPException(422, "Origin and destination must differ")
    if depart_date < date.today():
        raise HTTPException(422, "Departure date is in the past")
    if return_date and return_date < depart_date:
        raise HTTPException(422, "Return date is before departure")
    if not settings.duffel_token:
        raise HTTPException(503, "No flight provider is configured")

    provider = DuffelProvider(settings.duffel_token)
    status: dict[str, str] = {}
    offers = []
    try:
        offers = await provider.search(origin, destination, depart_date,
                                       return_date, adults, cabin)
        status[provider.name] = "ok"
    except ProviderError as e:
        status[provider.name] = f"unavailable: {e}"
    if not offers and all(v != "ok" for v in status.values()):
        raise HTTPException(502, detail=status)

    if currency:
        target = currency.upper()
        try:
            for o in offers:
                if o.currency != target:
                    o.converted_price, o.fx_rate, o.fx_as_of = await convert(
                        o.price, o.currency, target)
                    o.converted_currency = target
        except CurrencyError as e:
            status["currency"] = f"unavailable: {e}"
            for o in offers:
                o.converted_price = o.converted_currency = o.fx_rate = o.fx_as_of = None
    offers.sort(key=lambda x: x.converted_price if x.converted_price is not None else x.price)
    return SearchResponse(offers=offers, provider_status=status)
