from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    duffel_token: str = ""
    app_api_key: str = ""
    database_url: str = "sqlite:///./flightiq.db"
    check_interval_minutes: int = 360
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")


settings = Settings()
