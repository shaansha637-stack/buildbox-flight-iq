from datetime import date
from typing import Protocol

from ..schemas import FlightOffer


class ProviderError(Exception):
    """Safe-to-show error from a flight data provider."""


class FlightProvider(Protocol):
    name: str

    async def search(
        self,
        origin: str,
        destination: str,
        depart_date: date,
        return_date: date | None,
        adults: int,
        cabin: str,
    ) -> list[FlightOffer]: ...
