import logging
import re
from datetime import date

import httpx

from ..schemas import FlightOffer
from .base import ProviderError

log = logging.getLogger("flightiq.duffel")
BASE_URL = "https://api.duffel.com"


def parse_duration(iso: str | None) -> int:
    """ISO 8601 duration like PT6H8M or P1DT2H -> minutes."""
    if not iso:
        return 0
    m = re.fullmatch(r"P(?:(\d+)D)?(?:T(?:(\d+)H)?(?:(\d+)M)?)?", iso)
    if not m:
        return 0
    d, h, mi = (int(x or 0) for x in m.groups())
    return d * 1440 + h * 60 + mi


class DuffelProvider:
    name = "duffel"

    def __init__(self, token: str):
        self.token = token
        self.source = "test" if token.startswith("duffel_test") else "live"

    async def search(
        self,
        origin: str,
        destination: str,
        depart_date: date,
        return_date: date | None,
        adults: int,
        cabin: str,
    ) -> list[FlightOffer]:
        slices = [{"origin": origin, "destination": destination,
                   "departure_date": depart_date.isoformat()}]
        if return_date:
            slices.append({"origin": destination, "destination": origin,
                           "departure_date": return_date.isoformat()})
        body = {"data": {"slices": slices,
                         "passengers": [{"type": "adult"} for _ in range(adults)],
                         "cabin_class": cabin}}
        headers = {
            "Authorization": f"Bearer {self.token}",
            "Duffel-Version": "v2",
            "Accept": "application/json",
            "Content-Type": "application/json",
        }
        try:
            async with httpx.AsyncClient(timeout=30) as client:
                r = await client.post(
                    f"{BASE_URL}/air/offer_requests",
                    params={"return_offers": "true", "supplier_timeout": "15000"},
                    json=body, headers=headers)
        except httpx.HTTPError as e:
            log.warning("Duffel network error: %s", type(e).__name__)
            raise ProviderError("Could not reach Duffel.") from e

        if r.status_code == 429:
            raise ProviderError("Duffel rate limit reached. Try again shortly.")
        if r.status_code >= 400:
            log.warning("Duffel error %s: %s", r.status_code, r.text[:300])
            raise ProviderError(f"Duffel returned an error ({r.status_code}).")

        offers: list[FlightOffer] = []
        for o in r.json().get("data", {}).get("offers", []):
            try:
                out = o["slices"][0]
                segs = out["segments"]
                first, last = segs[0], segs[-1]
                carrier = first["marketing_carrier"]["iata_code"]
                offers.append(FlightOffer(
                    id=o["id"],
                    provider=self.name,
                    source=self.source,
                    airline=o["owner"]["name"],
                    flight_number=f'{carrier}{first["marketing_carrier_flight_number"]}',
                    origin=first["origin"]["iata_code"],
                    destination=last["destination"]["iata_code"],
                    depart_at=first["departing_at"],
                    arrive_at=last["arriving_at"],
                    duration_minutes=parse_duration(out.get("duration")),
                    stops=len(segs) - 1,
                    price=float(o["total_amount"]),
                    currency=o["total_currency"],
                ))
            except (KeyError, IndexError, ValueError, TypeError):
                log.warning("Skipped malformed Duffel offer")
        return offers
