from datetime import date, datetime
from typing import Literal

from pydantic import BaseModel, ConfigDict, Field

Cabin = Literal["economy", "premium_economy", "business", "first"]


class FlightOffer(BaseModel):
    id: str
    provider: str
    source: Literal["live", "test"]  # "test" = sandbox token, not real fares
    airline: str
    flight_number: str
    origin: str
    destination: str
    depart_at: str
    arrive_at: str
    duration_minutes: int
    stops: int
    price: float
    currency: str  # provider's ORIGINAL price/currency
    converted_price: float | None = None
    converted_currency: str | None = None
    fx_rate: float | None = None
    fx_as_of: str | None = None


class SearchResponse(BaseModel):
    offers: list[FlightOffer]
    provider_status: dict[str, str]


class TrackerIn(BaseModel):
    origin: str = Field(pattern=r"^[A-Za-z]{3}$")
    destination: str = Field(pattern=r"^[A-Za-z]{3}$")
    depart_date: date
    return_date: date | None = None
    adults: int = Field(default=1, ge=1, le=9)
    cabin: Cabin = "economy"
    currency: Literal["SAR", "USD", "EUR", "GBP", "INR", "AED"] = "SAR"
    target_price: float | None = Field(default=None, gt=0)


class TrackerOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    origin: str
    destination: str
    depart_date: date
    return_date: date | None
    adults: int
    cabin: str
    currency: str
    target_price: float | None
    active: bool
    latest_price: float | None = None
    lowest_price: float | None = None


class PointOut(BaseModel):
    checked_at: datetime
    price: float


class HistoryOut(BaseModel):
    currency: str
    points: list[PointOut]
    lowest: float | None = None
    highest: float | None = None
    latest: float | None = None
    average: float | None = None
    change_pct: float | None = None
    last_checked: datetime | None = None


class AlertOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    tracker_id: int
    kind: str
    old_price: float | None
    new_price: float
    currency: str
    pct: float | None
    message: str
    created_at: datetime
    delivered: bool


class AckIn(BaseModel):
    ids: list[int]
