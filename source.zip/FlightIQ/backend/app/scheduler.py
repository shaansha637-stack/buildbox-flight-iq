from apscheduler.schedulers.asyncio import AsyncIOScheduler

from .config import settings
from .services.checker import check_all

scheduler = AsyncIOScheduler()


def start():
    scheduler.add_job(check_all, "interval", minutes=settings.check_interval_minutes,
                      id="check_all", replace_existing=True, max_instances=1,
                      coalesce=True)
    scheduler.start()


def stop():
    scheduler.shutdown(wait=False)
