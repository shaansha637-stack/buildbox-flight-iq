from typing import Annotated

from fastapi import APIRouter, BackgroundTasks, Depends, Header, HTTPException
from sqlalchemy import func, select
from sqlalchemy.orm import Session

from .db import get_db
from .models import Alert, PricePoint, Tracker
from .schemas import (AckIn, AlertOut, HistoryOut, PointOut, TrackerIn,
                      TrackerOut)
from .services.checker import check_one
from .services.currency import CurrencyError, get_rates

DeviceId = Annotated[str, Header(min_length=8, max_length=64)]
router = APIRouter(prefix="/v1")


def _own(db: Session, tracker_id: int, device: str) -> Tracker:
    t = db.get(Tracker, tracker_id)
    if not t or t.device_id != device:
        raise HTTPException(404, "Tracker not found")
    return t


@router.post("/trackers", response_model=TrackerOut)
def create_tracker(body: TrackerIn, bg: BackgroundTasks, x_device_id: DeviceId,
                   db: Session = Depends(get_db)):
    if body.return_date and body.return_date < body.depart_date:
        raise HTTPException(422, "Return date is before departure")
    count = db.scalar(select(func.count()).select_from(Tracker).where(
        Tracker.device_id == x_device_id, Tracker.active.is_(True)))
    if count >= 10:
        raise HTTPException(429, "Maximum 10 active trackers")
    t = Tracker(device_id=x_device_id, origin=body.origin.upper(),
                destination=body.destination.upper(), depart_date=body.depart_date,
                return_date=body.return_date, adults=body.adults, cabin=body.cabin,
                currency=body.currency, target_price=body.target_price)
    db.add(t)
    db.commit()
    bg.add_task(check_one, t.id)  # first price point right away
    return TrackerOut.model_validate(t)


@router.get("/trackers", response_model=list[TrackerOut])
def list_trackers(x_device_id: DeviceId, db: Session = Depends(get_db)):
    out = []
    for t in db.scalars(select(Tracker).where(Tracker.device_id == x_device_id)
                        .order_by(Tracker.id.desc())):
        o = TrackerOut.model_validate(t)
        pts = list(db.scalars(select(PricePoint).where(PricePoint.tracker_id == t.id)
                              .order_by(PricePoint.id)))
        if pts:
            o.latest_price = pts[-1].price
            o.lowest_price = min(p.price for p in pts)
        out.append(o)
    return out


@router.delete("/trackers/{tracker_id}")
def delete_tracker(tracker_id: int, x_device_id: DeviceId, db: Session = Depends(get_db)):
    t = _own(db, tracker_id, x_device_id)
    for p in db.scalars(select(PricePoint).where(PricePoint.tracker_id == t.id)):
        db.delete(p)
    db.delete(t)
    db.commit()
    return {"ok": True}


@router.get("/trackers/{tracker_id}/history", response_model=HistoryOut)
def history(tracker_id: int, x_device_id: DeviceId, db: Session = Depends(get_db)):
    t = _own(db, tracker_id, x_device_id)
    pts = list(db.scalars(select(PricePoint).where(PricePoint.tracker_id == t.id)
                          .order_by(PricePoint.id)))
    out = HistoryOut(currency=t.currency,
                     points=[PointOut(checked_at=p.checked_at, price=p.price) for p in pts])
    if pts:
        prices = [p.price for p in pts]
        out.lowest, out.highest, out.latest = min(prices), max(prices), prices[-1]
        out.average = sum(prices) / len(prices)
        out.last_checked = pts[-1].checked_at
        if len(prices) > 1 and prices[-2]:
            out.change_pct = (prices[-1] - prices[-2]) / prices[-2] * 100
    return out


@router.get("/alerts", response_model=list[AlertOut])
def alerts(x_device_id: DeviceId, db: Session = Depends(get_db)):
    return list(db.scalars(select(Alert).where(Alert.device_id == x_device_id)
                           .order_by(Alert.id.desc()).limit(50)))


@router.post("/alerts/ack")
def ack(body: AckIn, x_device_id: DeviceId, db: Session = Depends(get_db)):
    for a in db.scalars(select(Alert).where(Alert.device_id == x_device_id,
                                            Alert.id.in_(body.ids))):
        a.delivered = True
    db.commit()
    return {"ok": True}


@router.get("/currency/rates")
async def rates(base: str = "SAR"):
    try:
        r, as_of = await get_rates(base)
    except CurrencyError as e:
        raise HTTPException(502, str(e))
    keep = ["SAR", "USD", "EUR", "GBP", "INR", "AED"]
    return {"base": base.upper(), "as_of": as_of,
            "rates": {k: r[k] for k in keep if k in r},
            "attribution": "https://www.exchangerate-api.com"}
